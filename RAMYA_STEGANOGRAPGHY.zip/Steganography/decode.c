#include "decode.h"
#include "enum.h"
#include <string.h>
#include <stdio.h>
#include "validate.h"
#include "encode.h"
#include "ui.h"

#define MAGIC_STRING "#*"

/* Open files for decoding */
Status open_decode_files(DecodeInfo *decInfo)
{
    /* Open the source image file in read mode */
    decInfo->output_image_fptr = fopen(decInfo->output_image_fname, "r");

    /* Check if the file was opened successfully */
    if (decInfo->output_image_fptr == NULL)
    {
    	perror("fopen");
    	fprintf(stderr,RED "ERROR: Unable to open file %s\n", decInfo->output_image_fname);

    	return failure;
    }

    return success;
}

/* Decode magic string */
Status decode_magic_string(const char *magic_string, DecodeInfo *decInfo)
{
    char decoded_magic_string[strlen(magic_string)+1];

    char buffer_8[8];

    //move the file offset to the 54th position (after header) to read magic string
    fseek(decInfo->output_image_fptr,54,SEEK_SET);

    for(int i = 0; i < strlen(magic_string); i++)
    {
        /* Read 8 bytes from the output image file */
        fread(buffer_8, 1, 8, decInfo->output_image_fptr);

        /* function call for decoding 1 byte from lsb and store in decoded_magic_string */
        decode_1byte_from_lsb(buffer_8, &decoded_magic_string[i]);

    }
    decoded_magic_string[strlen(magic_string)] = '\0'; //null terminate the string

    /* compare the decoded magic string with orignal magic string*/
    if(strcmp(decoded_magic_string,MAGIC_STRING) == 0)
    {
         printf(GREEN"Magic string decoded successfully...\n"RESET);
         return success;
    }
    else
    {
        /* Print error message and return failure */
        fprintf(stderr,RED"ERROR: Magic string not found. Decoding failed.\n"RESET);
        return failure;
    }
     
}

/* Decode secret file extension */
Status decode_secret_file_extn(DecodeInfo *decInfo)
{
    char buffer_32[32];

    /* Read 32 bytes from the output image file for secret file extn size */
    fread(buffer_32, 1, 32, decInfo->output_image_fptr);

    /* function call for decoding 4 byte from lsb and store in secret_extn_size */
    decInfo->secret_extn_size = decode_4byte_from_lsb(buffer_32);
     printf(CYAN"Secret file extension size: %d\n"RESET,decInfo->secret_extn_size);

    char buffer_8[8];
    char secret_extn[decInfo->secret_extn_size+1];

    /* Read 8 bytes from the output image file for secret file extn */
    for(int i = 0; i < decInfo->secret_extn_size; i++)
    {
        fread(buffer_8, 1, 8, decInfo->output_image_fptr);

        /* function call for decoding 1 byte from lsb and store in secret_extn */
        decode_1byte_from_lsb(buffer_8, &secret_extn[i]);
    }
    secret_extn[decInfo->secret_extn_size] = '\0'; // null terminate the string

    strcpy(decInfo->secret_extn, secret_extn);
        printf(CYAN"Secret file extension: %s\n"RESET,decInfo->secret_extn);
    /* Concatenate the secret file extension with the secret file name */
    strcat(decInfo->secret_fname, decInfo->secret_extn);

    decInfo->secret_fptr = fopen(decInfo->secret_fname, "w"); // Open the secret file with the complete name (name + extn) in write mode
    if(decInfo->secret_fptr == NULL)
    {
        perror("fopen");
        fprintf(stderr, RED"ERROR: Unable to create file %s\n"RESET, decInfo->secret_fname);
        return failure;
    }

     /* Check if the file was opened successfully */
    printf(ORANGE"Secret file name with extension: %s\n"RESET, decInfo->secret_fname);

    printf("Secret file extension decoded successfully...\n");
    return success;
}

/* Decode secret file data */
Status decode_secret_file_data(DecodeInfo *decInfo)
{
    char buffer_32[32];

    /* Read 32 bytes from the output image file for secret file size */
    fread(buffer_32, 1, 32, decInfo->output_image_fptr);

    /* function call for decoding 4 byte from lsb and store in secret_file_size */
    unsigned long int secret_file_size = decode_4byte_from_lsb(buffer_32);
    printf(PURPLE"Secret file size decoded : %lu bytes\n"RESET, secret_file_size);

    char buffer_8[8];
    /* function call for decoding secret file data from lsb and write to secret file */
    for(int i = 0; i < secret_file_size; i++)
    {
        /* Read 8 bytes from the output image file */
        fread(buffer_8, 1, 8, decInfo->output_image_fptr);

        /* variable to store decoded byte from lsb */
        char data;

        /* function call for decoding 1 byte from lsb and store in data */
        decode_1byte_from_lsb(buffer_8, &data);

        /* Write the decoded byte to the secret file */
        fwrite(&data, 1, 1, decInfo->secret_fptr);
       // printf("%c", data); // print the decoded data to console
    }

    printf(GREEN"Secret file data decoded and written to %s successfully.😎\n"RESET, decInfo->secret_fname);
}

/* Decode 1 byte from LSB of image data array */
char decode_1byte_from_lsb(char *buffer_8, char *data)
{
    /* Get the lsb bit from encoded data and replace the msb bit */
    
    *data = 0; // Initialize data to 0 before setting bits
    for (int i = 0; i < 8; i++)
    {
        int bit = buffer_8[i] & 1; // Get the least significant bit
        *data = *data | (bit << (7 - i)); // Shift data left and add the lsb bit
    }
    return *data;
}

/* Decode 4 byte (int) from LSB of image data array */
int decode_4byte_from_lsb(char *buffer_32)
{
    int data = 0; // Initialize data to 0 before setting bits
    for (int i = 0; i < 32; i++)
    {
        int bit = buffer_32[i] & 1; // Get the least significant bit
        data = data | (bit << (31 - i)); // Shift bit left and add the data bit
    }
    return data;
}

/* Perform the decoding */
Status do_decoding(char *argv[], DecodeInfo *decInfo)
{
   
    if (open_decode_files(decInfo) == failure)
    {
        return failure;
    }
     

    /* Decode magic string */
    if (decode_magic_string(MAGIC_STRING, decInfo) == failure)
    {
        printf(RED"ERROR: Failed to decode magic string‼️\n"RESET);
        return failure;
    }

    /* Decode secret file extension */
   if( decode_secret_file_extn(decInfo) == failure)
    {
        printf(RED"ERROR: Failed to decode secret file extension‼️\n"RESET);
        return failure;
    }

    /* Decode secret file data */
    if( decode_secret_file_data(decInfo) == failure)
    {
        printf(RED"ERROR: Failed to decode secret file data‼️\n"RESET);
        return failure;
    }
    
    fclose(decInfo->output_image_fptr); // Close the output image file
    fclose(decInfo->secret_fptr); // Close the secret file
    return success;
}
