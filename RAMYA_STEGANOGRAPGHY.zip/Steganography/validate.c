#include "main.h"
#include "encode.h"
#include "enum.h"
#include <string.h>
#include <stdio.h>
#include "validate.h"
#include "ui.h"



Status validate_encode_args(char *argv[],EncodeInfo *encInfo)
{
    /* SOURCE FILE VALIDATION */

     // Get the file extension of the source image file using strstr() and store in a temporary string variable
    char *src = strstr(argv[2], "."); 
    printf(PINK"Source Image file is : %s\n"RESET,argv[2]);

   /* Initialize the temporay string with ".bmp" to check extension of the source image file we need*/
   char src_str[5]=".bmp";  //source string
   src_str[4] = '\0';

   /* Check if the source image file extension is .bmp or not */
   if(src != NULL && strcmp(src, src_str) == 0)
   {
      /* Store the source image filename in encInfo (structure) */
      encInfo->src_image_fname = argv[2]; 
   }
   else
   {
      /* Print error message and return failure */
      printf(RED"ERROR: Invalid file format. Please provide a .bmp file for source image....\n"RESET);
      return failure;
   }
  
   /* SECRET FILE VALIDATION */

   // Get the file extension of the secret file using strstr() & store in a temp str var
   char *sec = strstr(argv[3], ".");
   printf(PINK"Hidden data file is : %s\n"RESET,argv[3]);

   /* Initialize the temporay string with ".txt" or ".c" or ".cpp" to check extension of the secret file we need*/
   char sec_str[3][5]={".txt", ".c", ".cpp"};  //secret string -array of strings to check for .txt, .c, .cpp
   int i;
   int flag=0; //flag to check if any valid extension is matched or not  

   /* loop to check all valid secret file extensions */
   for(i=0; i<3; i++) 
   {
      if(sec != NULL && strcmp(sec, sec_str[i]) == 0)
      {
         flag=1; //valid extension matched
         /* Store the secret filename in encInfo (structure) */
         encInfo->secret_fname = argv[3];

         /* Extract the filename into structure secret_extn*/
         strcpy(encInfo->secret_extn, sec);

         /* Get the secret file extension size and store in structure secret_extn_size */
         encInfo->secret_extn_size = strlen(encInfo->secret_extn);
         printf(BLUE"Secret file extension size: %d\n"RESET, encInfo->secret_extn_size);

         break; //break loop if valid extension is found
      }
      
   }
   if(flag == 0) //if no valid extension matched
   {
      /* Print error message and return failure */
      printf(RED"ERROR: Invalid file format. Please provide a .txt or .c or .cpp file for secret file....\n"RESET);
      return failure;
   }

   /* OUTPUT FILE VALIDATION */

   /* if output file is provided i.e., != NULL */
   if(argv[4] != NULL)
   {
      // Get the file extension of the output img file using strstr() & store in a temp str var
      char *out = strstr(argv[4], ".");

      /* Initialize the temporay string with ".bmp" to check extension of the output image file we need*/
      char out_str[5]=".bmp";  //output string
      out_str[4] = '\0';
         printf(PINK"Output image file extn is : %s\n"RESET,out_str);

         /* Check if the output image file extension is .bmp or not */
      if(out != NULL && strcmp(out, out_str) == 0)
      {
         /* Store the output image filename in encInfo (structure) */
         encInfo->output_image_fname = argv[4];
         printf(PINK"Output image file is : %s\n"RESET,encInfo->output_image_fname);
      }
      else
      {
         /* Print error message and return failure */
         printf(RED"ERROR: Invalid file format. Please provide a .bmp file for output image....\n"RESET);
         return failure;
      }
   }
   else if(argv[4] == NULL)
   {
      /* If output image file is not provided, store default filename in encInfo (structure) */
      encInfo->output_image_fname = "stego.bmp";
      printf(PINK"Output file is not provided. Default output image file is : %s\n"RESET,encInfo->output_image_fname);
   }  
   
   return success;
}


   Status validate_decode_args(char *argv[], DecodeInfo *decInfo, int argc)
{

  /* OUTPUT FILE VALIDATION */

/* Get the file extension of the output image file using strstr() and store in a temporary string variable */
    char *out = strstr(argv[2], "."); 

    /* Initialize the temporay string with ".bmp" to check extension of the output image file we need*/
    char out_str[5]=".bmp";  //output string
    out_str[4] = '\0';
    printf(PINK"Output Image file extn is : %s\n"RESET,out_str);

    /* Check if the output image file extension is .bmp or not */
    if(out != NULL && strcmp(out, out_str) == 0)
    {
        /* Store the output image filename in decInfo (structure) */
        decInfo->output_image_fname = argv[2];
        printf(BLUE"Output Image file is : %s\n"RESET,decInfo->output_image_fname);
    }
    else
    {
        /* Print error message and return failure */
        printf(RED"ERROR: Invalid file format. Please provide a .bmp file for output image....\n"RESET);
        return failure;
    }
    /* SECRET FILE VALIDATION */
   if(argv[3] != NULL)
    {
          strcpy(decInfo->secret_fname,argv[3]);

            char *p = strchr(decInfo->secret_fname, '.');

            if(p != NULL)
            {
                *p = '\0';
              
            }

              printf("decode_secret_file name is : %s\n",
                   decInfo->secret_fname);
                   return success;
      }
      else if(argv[3] == NULL)
      {
            strcpy(decInfo->secret_fname, "decode_secret");

            printf("Decode secret file is not provided. Default secret file name is : %s\n",decInfo->secret_fname);
             return success;
      } 
      else
      {

            printf(RED"ERROR: Invalid file format. Please provide a .txt or .c or .cpp file for decode secret file....\n"RESET);
            return failure;
      }

}

