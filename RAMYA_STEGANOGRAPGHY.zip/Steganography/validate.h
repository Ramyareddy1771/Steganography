#ifndef VALIDATE_H
#define VALIDATE_H

#include "enum.h"
#include "encode.h"
#include "decode.h"


typedef struct EncodeInfo EncodeInfo;
typedef struct DecodeInfo DecodeInfo;

/* Read and validate Encode args from argv */
Status validate_encode_args(char *argv[], EncodeInfo *encInfo);

/* Read and validate Decode args from argv */
//Status validate_decode_args(char *argv[], DecodeInfo *decInfo);
 Status validate_decode_args(char *argv[], DecodeInfo *decInfo, int argc);

#endif