/*    DOCUMENTATION
    NAME           : RAMYA AMBATI
    DATE           : 22-05-2026
    PROJECT TITLE  : STEGANOGRAPHY
    DESCRIPTION    : This project implements a steganography tool
                     that allows users to hide secret messages within BMP image files.
                     The tool provides two main functionalities in main: encoding and decoding. 

    OPERATIONS USED: 1. Encoding: The encoding process takes a source BMP image file & a secret text file as input.
                        It hides the contents of the secret text file within the pixel data of the BMP image using  (LSB).
                        The output is a new BMP image file that contains the hidden message.
                     2. Decoding: The decoding process takes a BMP image file that contains a hidden message as input.
                        It extracts the hidden message from the pixel data of the BMP image and saves it
                        to a specified output text file.

    NOTE           : 1. The output file name for encoding is optional. If not provided, the user will prompt to enter the output file name.
                     2. The secret file name for decoding is optional. If not provided, the user will prompt to enter the secret file name.
                     3. The program validates the input arguments and prints appropriate error messages for invalid inputs.
                     4. The program uses a loading animation to indicate the progress of validation and encoding/decoding processes.
        
    OBJECTIVE      : 1. To implement a steganography tool that can hide secret messages within BMP image files.
                     2. To ensure the security of the hidden messages by using LSB technique for encoding and decoding.
                     3. To validate input arguments and handle errors.
    
    COMPILER       : gcc (GNU Compiler Collection)

    FILES          : 1. main.c - Contains the main function and handles user input and operation selection.
                     2. encode.c - Contains functions related to encoding the secret message into the BMP image.
                     3. decode.c - Contains functions related to decoding the hidden message from the BMP image.
                     4. validate.c - Contains functions for validating input arguments for encoding and decoding operations.
                     5. enum.h - Contains enumerations for operation types and status codes.
                     6. main.h - Contains function prototypes and structure definitions for encoding and decoding information.
                     7. ui.h - Contains function prototypes for user interface elements such as color codes for console output.
                     8. animation.h - Contains function prototypes for loading animations.

    COMMANDS       : To Compile : gcc *.c
                     To Run     : 1. Encoding: ./a.out -e <source.bmp> <secret.txt> [output.bmp]
                                    2. Decoding: ./a.out -d <stego.bmp> [decode_secret.txt]
*/

#include <stdio.h>
#include <string.h>
#include "enum.h"
#include "main.h"
#include "validate.h"
#include "encode.h"
#include "decode.h"
#include "animation.h"
#include "ui.h"

Opr_type check_operation(char *option)
{
   
   if(strcmp(option, "-e") == 0)
   {
      return encode;
   }
   else if(strcmp(option, "-d") == 0)
   {
      return decode;
   }
   else
   {
      return unsupported;
   }
}
int main(int argc, char *argv[])
{
    EncodeInfo encInfo;
    DecodeInfo decInfo;

    if( argc == 1 )
    {
        // print -> Error + usage msg
        printf(YELLOW"Usage:\n"RESET);
        printf(YELLOW"Encoding: ./a.out -e <source.bmp> <secret.txt> [output.bmp]\n"RESET);
        printf(YELLOW"Decoding: ./a.out -d <stego.bmp> [output.txt]\n"RESET);
        return failure;
    }

    /* function call to check operation of encode and decode */
    int opr = check_operation(argv[1]);

    if( opr == encode )
    {
        /* false condition */
        if( argc < 4 || argc > 5 )
        {
            // print -> Error + usage msg
            fprintf(stderr, RED"ERROR: Invalid number of arguments‼️\n"RESET);
            fprintf(stderr, YELLOW"Usage: ./a.out -e <source.bmp> <secret.txt> [output.bmp]\n"RESET);
            return failure;
        }
        else 
        {
            printf("Validating->");
            loading_animation();
            /* success - function call to validate encode arguments (source image file, secret file, output image file) */
        int valid = validate_encode_args(argv, &encInfo);
            if(valid == success)
            {
                printf(YELLOW"Validation of encode arguments successful...✅\n"RESET);
                printf(GREEN"##Encoding Process Started ##\n"RESET);
                loading_animation(); // Call the loading animation function to show animation while validating arguments
                do_encoding(argv, &encInfo);
            }
            else
            {
                 /* Print error message and return failure */
                    fprintf(stderr, RED"ERROR: Failed to validate encode arguments‼️\n"RESET);
                     fprintf(stderr, YELLOW"Usage: ./a.out -e <source.bmp> <secret.txt> [output.bmp]\n"RESET);
                    return failure;     
            }
        }
    }
    else if( opr == decode )
    {
        if( argc < 3 || argc > 4 )	
        {
            // print -> Error + usage msg
            fprintf(stderr, RED"ERROR: Invalid number of arguments‼️\n"RESET);
             fprintf(stderr, YELLOW"Usage: ./a.out -d <stego.bmp> [decode_secret.txt]\n"RESET);
            return failure;
        }
        else 
        {
             printf("Validating->");
            loading_animation();
            
            /* success - function call to validate decode arguments (source image file, secret file, output image file) */
        int valid = validate_decode_args(argv, &decInfo,argc);
            if(valid == success)
            {
                printf(ORANGE"Validation of decode arguments successful...✅\n"RESET);
                printf(YELLOW"##Decoding Process Started...##\n"RESET);
                loading_animation(); // Call the loading animation function to show animation while validating arguments
                do_decoding(argv, &decInfo);
            }
            else
            {
                 /* Print error message and return failure */
                    fprintf(stderr, RED"ERROR: Failed to validate decode arguments‼️\n"RESET);
                     fprintf(stderr, YELLOW"Usage: ./a.out -d <stego.bmp> [decode_secret.txt]\n"RESET);
                    return failure;               
            }
        }
    }
    else
    {
	     // Print -> Error + usage msg
        fprintf(stderr, RED"ERROR: Unsupported operation‼️\n"RESET);
        return failure;
    }

}
