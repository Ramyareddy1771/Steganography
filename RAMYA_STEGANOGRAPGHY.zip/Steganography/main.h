#ifndef MAIN_H
#define MAIN_H

#include "enum.h"


/* Check operation type */
Opr_type check_operation(char *option);



#endif