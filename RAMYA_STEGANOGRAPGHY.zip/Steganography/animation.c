#include <stdio.h>
#include <unistd.h>
#include "animation.h"
#include "encode.h"
#include "decode.h"
void loading_animation()
    {
        char str[]=".........";
         for(int i=0;str[i] != '\0';i++ )
        {
            printf(" %c",str[i]);
            fflush(stdout);
            usleep(100000);// 0.1sec delay
        }
        printf("\n");
    }
void copy_animation()
    {
        
        char str[]="....";
         for(int i=0;str[i] != '\0';i++ )
        {
            printf(" %c",str[i]);
            fflush(stdout);
            sleep(1);// 1sec delay
        }
        printf("\n");
    }