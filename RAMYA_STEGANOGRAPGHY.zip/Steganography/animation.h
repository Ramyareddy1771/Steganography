#ifndef ANIMATION_H
#define ANIMATION_H

void copy_animation();
void loading_animation();

#endif