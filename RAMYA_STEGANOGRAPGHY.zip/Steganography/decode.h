#ifndef DECODE_H
#define DECODE_H

#include "enum.h"
#include<stdio.h>

typedef struct DecodeInfo
{
    /* Stego Image Info */
    char *output_image_fname;   // => Store the Output_img_fname
    FILE *output_image_fptr;    // => File pointer for output_Img

    /* Secret file name */
    char secret_fname[26];    


    /* Secret file pointer */
    FILE *secret_fptr;

    int secret_extn_size;  // => Store the secret file extn size
    char secret_extn[7];   // => Store the secret file extn

}DecodeInfo;

/********** Function Prototypes **********/



/* Open files for decoding */
Status open_decode_files(DecodeInfo *decInfo);

/* Perform the decoding */
Status do_decoding(char *argv[], DecodeInfo *decInfo);

/* Decode magic string */
Status decode_magic_string(const char *magic_string, DecodeInfo *decInfo);

/* Decode secret file extension */
Status decode_secret_file_extn(DecodeInfo *decInfo);

/* Decode secret file data */
Status decode_secret_file_data(DecodeInfo *decInfo);

/* Decode 1 byte from LSB of image data array */
char decode_1byte_from_lsb(char *buffer_8, char *data);

/* Decode 4 byte (int) from LSB of image data array */
int decode_4byte_from_lsb(char *buffer_32);

#endif

