#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "encode.h"
#include "enum.h"
#include "ui.h"
#include "animation.h"
#define MAGIC_STRING "#*" 

Status open_files(EncodeInfo *encInfo)
{
    /* Open the source image file in read mode */
    encInfo->src_image_fptr = fopen(encInfo->src_image_fname, "r");

    /* Check if the file was opened successfully */
    if (encInfo->src_image_fptr == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

    	return failure;
    }


    /* Open the secret file in read mode */
    encInfo->secret_fptr = fopen(encInfo->secret_fname, "r");

        /* Check if the file was opened successfully */
    if (encInfo->secret_fptr == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

    	return failure;
    }


    /* Open the output image file in write mode */
    encInfo->output_image_fptr = fopen(encInfo->output_image_fname, "w");

    /* Check if the file was opened successfully */
    if (encInfo->output_image_fptr == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->output_image_fname);

    	return failure;
    }

    /* If all files are opened successfully, return success */
    return success;
}

Status check_capacity(EncodeInfo *encInfo)
{
    unsigned int img_capacity = get_image_size_for_bmp(encInfo->src_image_fptr);
    if (img_capacity == failure)
    {
        return failure;
    }
    printf("Image capacity (in bytes): %u\n",img_capacity);

     /* Get the size of the secret file */
    encInfo->secret_file_size = get_file_size(encInfo->secret_fptr);
    printf(CYAN"Secret file size (in bytes): %lu\n"RESET, encInfo->secret_file_size);

    /*  Print the magic string */
     //printf("Magic string: %s\n", MAGIC_STRING);

     // Calculate the total number of bits needed for encoding the magic string, sec_file_extn_size,sec_file_extn,size of sec_msg in int & sec_mag
    int enc_len = (strlen(MAGIC_STRING) + 4 +strlen(encInfo->secret_extn) + 4 + encInfo-> secret_file_size) * 8;
    //printf("Total bits needed for encoding: %d\n", enc_len);

    /* Check if the image has sufficient capacity or not*/
    if (img_capacity < enc_len)
    {
        fprintf(stderr,RED"ERROR: Insufficient image capacity for encoding\n"RESET);
        return failure;
    }
    else
    {
        printf(PINK"Sufficient image capacity for encoding\n"RESET);
        return success;
    }

}

/* Get image size
 * Input: Image_file_ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */
unsigned int get_image_size_for_bmp(FILE *src_image_fptr)
{
    unsigned int width, height;
    /* Seek to 18th byte */
    fseek(src_image_fptr, 18, SEEK_SET);

    /* Read the width (an int) */
    fread(&width, sizeof(int), 1, src_image_fptr); //18 - 21 are for width
    //printf("width = %u\n", width);

    /* Read the height (an int) */
    fread(&height, sizeof(int), 1, src_image_fptr); //+4 -> 22 - 25 are for height
    //printf("height = %u\n", height);

    /* Return image capacity */
    return width * height * 3;
}

/* Get secret file size take Secret_file_ptr bas i/p & get size of the secret file in bytes*/
unsigned int get_file_size(FILE *secret_fptr)
{
    unsigned int file_size;

    /* Firstly, move the file pointer to the end of the file using fseek() */
    fseek(secret_fptr, 0, SEEK_END);

    /* Then, use ftell() to get the current position of the file ptr, which will give the size of file in bytes */
    file_size = ftell(secret_fptr);
    return file_size;
}


/* Copy bmp image header */
Status copy_bmp_header(EncodeInfo *encInfo)
{
    /* Move the file offset  to 0th index */
    fseek(encInfo->src_image_fptr,0,SEEK_SET);
    // printf("Now file is at %ldth index\n",ftell(encInfo->src_image_fptr));
 
    /*char var because byte by byte data is read from src img file and stored in header_size var of 54 bytes size*/
     unsigned char header_size[54]; 

         /* Read 54 bytes from src img file*/
    fread(header_size,54,1,encInfo->src_image_fptr);

    /* Write 54 bytes to output img file */
    fwrite(header_size,54,1,encInfo->output_image_fptr);

    printf(ORANGE"Header copied successfully...\n"RESET);

    return success;
}

/* Store Magic String */
Status encode_magic_string(const char *magic_string, EncodeInfo *encInfo)
{
    char buffer[8];  /* declare char variable for buffer of 8 bytes from src_img_file*/ 
  
    int len=strlen(magic_string);
    //printf("len=%d\n",len);
    for(int i=0;i < len;i++)
    {
       
        /* Read 8 bytes from src_img_file*/
      fread(buffer,1,8,encInfo->src_image_fptr);

      /* function call for encoding magicstring to lsb length of magicstring times*/
      encode_1byte_to_lsb(buffer,magic_string[i]);

      /* Write those 8 bytes to output img file */
      fwrite(buffer,1,8,encInfo->output_image_fptr);
    }

    return success;

}

Status encode_secret_file_extn(EncodeInfo *encInfo)
{
    //encode the secret file extension size first
    char buffer_32[32];

    /* Read 32 bytes from src_img_file */
    fread(buffer_32,32,1,encInfo->src_image_fptr);
    
    /* function call for encoding secret file extn size length of sec file extn size times*/
    encode_4byte_to_lsb(encInfo->secret_extn_size, buffer_32);
    
    /* Write those 32 bytes to output img file */
    fwrite(buffer_32,32,1,encInfo->output_image_fptr);

    //encode the secret file extension next
    char buffer_8[8];
    /* function call for encoding secret file extn to lsb */
    for(int i = 0; i < strlen(encInfo->secret_extn); i++)
    {
        /* Read 8 bytes from src_img_file */
        fread(buffer_8, 8, 1, encInfo->src_image_fptr);

        encode_1byte_to_lsb(buffer_8,encInfo->secret_extn[i]);

        /* Write those 8 bytes to output img file */
        fwrite(buffer_8, 8, 1, encInfo->output_image_fptr);
    }

    return success;

}

/* Encode secret file data*/
Status encode_secret_file_data(EncodeInfo *encInfo)
{
       printf("secret file size %ld\n",encInfo->secret_file_size);
       char buffer_32[32];
       /* Read 32 bytes from src_img_fptr for secret data size */
        fread(buffer_32,1,32,encInfo->src_image_fptr);

        encode_4byte_to_lsb(encInfo->secret_file_size,buffer_32);// passing size of secret file and buffer

        /* Write 32 bytes to output_img_fptr*/
        fwrite(buffer_32,1,32,encInfo->output_image_fptr);
    /* declare variable for buffer of 8 bytes from src_img_file*/
    char buffer_8[8];
    rewind(encInfo->secret_fptr);
    //printf("file position at:%ld\n",ftell(encInfo->secret_fptr));
    /* function call for encoding secret file data to lsb */
    for(int i = 0; i < encInfo->secret_file_size; i++)
    {
        /* Read 8 bytes from src_img_file */
        fread(buffer_8, 8, 1, encInfo->src_image_fptr);

        /* Read one by one char from secret file */
        char data = fgetc(encInfo->secret_fptr);
        //printf("data :%c\n",data);

        /* Encode the read character into the LSB of the buffer */
        encode_1byte_to_lsb(buffer_8,data);

        /* Write those 8 bytes to output img file */
        fwrite(buffer_8, 8, 1, encInfo->output_image_fptr);
    }

    return success;
}

/* Encode 1 byte into LSB of image data array */
Status encode_1byte_to_lsb(char *buffer_8,char data)
{
    
     /* Print the original value of buffer_8[8] before encoding */
    //printf("Before encoding:\n");
    for (int i = 0; i < 8; i++)
    {
       // printf("0%hhx ", buffer_8[i]);
    }
    //printf("\n");

    //printf("After encoding:\n");
    
    for (int i = 0; i < 8; i++) //loop for magic string data bits -8
    {
            /* get one by one bit from data (start from MSB) */
            int bit= ((unsigned char)data >> (7-i)) & 1;
            /* clear the lsb bit and replace the lsb bit with bit from magic_string data*/
            buffer_8[i] = ((buffer_8[i]) & (~1)) | bit;
           // printf("0%hhx ", buffer_8[i]); 
    }
    //printf("\n");

    return success;
}

/* Encode 4byte(int) into LSB of image data array */
Status encode_4byte_to_lsb(int data, char *buffer_32)
{
    //printf("encoding data : %d\n", data);

     //printf("Before encoding:\n");
        for (int i = 0; i < 32; i++)
        {
            //printf("0%hhx ", buffer_32[i]);
        }   
    //printf("\n");

    //printf("After encodng:\n");
    for (int i = 0; i < 32; i++)
    {
            /* Clear the lsb bit of img file ,get one by one bit from MSB &Replace the lsb bit with bit from data */
            buffer_32[i] = (buffer_32[i] & ~(1)) | ((((unsigned char)data) >> (31-i)) & 1);
            //printf("0%hhx ", buffer_32[i]);
    }
    //printf("\n");

    return success;
}

/* Copy remaining image bytes from src to stego image after encoding */
Status copy_remaining_img_data(EncodeInfo * encInfo)
{
    char buffer;

    /* Read one byte at a time from src image file until end of file is reached */
    while (fread(&buffer, 1, 1, encInfo->src_image_fptr) == 1)
    {
        /* Write the read byte to output image file */
        fwrite(&buffer, 1, 1, encInfo->output_image_fptr);
    }
    
    printf("Copying remaining image data📥");
        /* Call the copy animation function to show animation while copying remaining data */
    copy_animation();

    return success;
}

/* Perform the encoding */
Status do_encoding(char *argv[], EncodeInfo *encInfo)
{
    int open_status = open_files(encInfo);
    if (open_status == failure)
    {
        printf(RED"ERROR: Failed to open files‼️\n"RESET);
        return failure;
    }
    else
    {
        printf(GREEN"All files opened successfully...\n"RESET);
    }

    /* Get the capacity of the image */
    int capacity_status = check_capacity(encInfo);
    if (capacity_status == failure)
    {
        printf(RED"ERROR: Insufficient image capacity for encoding‼️\n"RESET);
        return failure;
    }
    else
    {
        printf(BLUE"Capacity check passed successfully...\n"RESET);
    }

    /* function call for copying bmp img header */
    copy_bmp_header(encInfo); 

     /* Store Magic String */
    int magic=encode_magic_string(MAGIC_STRING,encInfo);
    if(magic == failure)
    {
        printf(RED"ERROR: Failed to encode magic string‼️\n"RESET);
        return failure;
    }
    else
    {
        printf(GREEN"Magic string encoded successfully...\n"RESET);
    }

    /* function call for encoding secret file extension */
    int sec_extn=encode_secret_file_extn(encInfo);
    if(sec_extn == failure)
    {
        printf(RED"ERROR: Failed to encode secret file extension‼️\n"RESET);
        return failure;
    }
    else
    {
        printf(PURPLE"Secret file extension encoded successfully...\n"RESET);
    }

    /* function call for encoding secret file data*/
    int sec_data=encode_secret_file_data(encInfo);
    if(sec_data == failure)
    {
        printf(RED"ERROR: Failed to encode secret file data‼️\n"RESET);
        return failure;
    }
    else
    {
        printf(ORANGE"Secret file data encoded successfully...\n"RESET);
    }

    /* function call for copying remaining image bytes from src to stego image after encoding */
    int copy_rem_data=copy_remaining_img_data(encInfo);
    if(copy_rem_data == failure)
    {
        printf(RED"ERROR: Failed to copy remaining image data‼️\n"RESET);
        return failure;
    }
    else
    {
        printf(CYAN"Remaining image data copied successfully...\n"RESET);
    }

     /* Close all the opened files */
    fclose(encInfo->src_image_fptr);
    fclose(encInfo->secret_fptr);
    fclose(encInfo->output_image_fptr);

    printf(GREEN"Encoding process completed successfully...😎\n"RESET);
    return success;

}


